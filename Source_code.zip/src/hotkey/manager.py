"""
全局热键管理器 —— RegisterHotKey
支持组合键和单键
"""
import ctypes
from ctypes import wintypes

from PyQt5.QtCore import QObject, pyqtSignal, QAbstractNativeEventFilter
from PyQt5.QtWidgets import QApplication

user32 = ctypes.windll.user32

MOD_ALT=0x0001; MOD_CONTROL=0x0002; MOD_SHIFT=0x0004; MOD_WIN=0x0008
WM_HOTKEY = 0x0312

VK_MAP = {chr(i):i for i in range(0x41,0x5B)}
VK_MAP.update({chr(i):i for i in range(0x30,0x3A)})
VK_MAP.update({k:v for k,v in {
    'F1':0x70,'F2':0x71,'F3':0x72,'F4':0x73,'F5':0x74,'F6':0x75,
    'F7':0x76,'F8':0x77,'F9':0x78,'F10':0x79,'F11':0x7A,'F12':0x7B,
    'SPACE':0x20,'TAB':0x09,'ENTER':0x0D,'ESC':0x1B,'BACKSPACE':0x08,
    'DELETE':0x2E,'HOME':0x24,'END':0x23,'UP':0x26,'DOWN':0x28,
    'LEFT':0x25,'RIGHT':0x27,'PAGEUP':0x21,'PAGEDOWN':0x22,
}.items()})


def parse_hotkey(s: str):
    parts = [p.strip().upper() for p in s.strip().split('+')]
    main = parts[-1]
    mods = 0
    for p in parts[:-1]:
        if p=='CTRL': mods|=MOD_CONTROL
        elif p=='SHIFT': mods|=MOD_SHIFT
        elif p=='ALT': mods|=MOD_ALT
        elif p=='WIN': mods|=MOD_WIN
    vk = VK_MAP.get(main, 0x56)
    return mods, vk


class HotkeyFilter(QAbstractNativeEventFilter):
    def __init__(self, cb): super().__init__(); self.cb = cb
    def nativeEventFilter(self, event_type, message):
        msg = wintypes.MSG.from_address(int(message))
        if msg.message == WM_HOTKEY:
            self.cb()
            return True, 0
        return False, 0


class HotkeyManager(QObject):
    hotkey_triggered = pyqtSignal()

    def __init__(self, hotkey="Alt+V", parent=None):
        super().__init__(parent)
        self._hotkey = hotkey
        self._hk_id = 1
        self._reg = False
        self._filter = None

    def start(self):
        self._do_register()
        if self._filter is None:
            self._filter = HotkeyFilter(self._on_trigger)
            QApplication.instance().installNativeEventFilter(self._filter)

    def _do_register(self):
        if self._reg:
            user32.UnregisterHotKey(None, self._hk_id)
            self._reg = False
        mods, vk = parse_hotkey(self._hotkey)
        ok = user32.RegisterHotKey(None, self._hk_id, mods, vk)
        if ok:
            self._reg = True
            print(f"[Hotkey] {self._hotkey} OK")
        else:
            print(f"[Hotkey] {self._hotkey} FAIL (err {ctypes.get_last_error()})")

    def _on_trigger(self):
        self.hotkey_triggered.emit()

    def update_hotkey(self, new: str):
        self._hotkey = new
        self._do_register()

    def stop(self):
        if self._reg:
            user32.UnregisterHotKey(None, self._hk_id)
            self._reg = False
        if self._filter:
            try: QApplication.instance().removeNativeEventFilter(self._filter)
            except: pass
            self._filter = None
