"""短语 CRUD 操作"""
from datetime import datetime
from typing import Optional
from .schema import get_connection, DB_PATH


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# Groups
# ============================================================

def get_all_groups(db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT id, name, parent_id, sort_order FROM groups ORDER BY sort_order, id"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def build_group_tree(flat: list[dict]) -> list[dict]:
    lookup = {}
    roots = []
    for g in flat:
        g["children"] = []
        lookup[g["id"]] = g
    for g in flat:
        pid = g.get("parent_id")
        if pid is None or pid == 0:
            roots.append(g)
        elif pid in lookup:
            lookup[pid]["children"].append(g)
        else:
            roots.append(g)
    return roots


def create_group(name: str, parent_id: Optional[int] = None, db_path: str = DB_PATH) -> int:
    conn = get_connection(db_path)
    cur = conn.execute(
        "INSERT INTO groups(name, parent_id, sort_order) VALUES(?,?,"
        "(SELECT COALESCE(MAX(sort_order),0)+1 FROM groups WHERE parent_id IS ?))",
        (name, parent_id, parent_id)
    )
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return new_id


def rename_group(group_id: int, new_name: str, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute("UPDATE groups SET name=? WHERE id=?", (new_name, group_id))
    conn.commit()
    conn.close()


def delete_group(group_id: int, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    parent_id = conn.execute("SELECT parent_id FROM groups WHERE id=?", (group_id,)).fetchone()
    new_parent = parent_id["parent_id"] if parent_id else None
    conn.execute("UPDATE groups SET parent_id=? WHERE parent_id=?", (new_parent, group_id))
    conn.execute("DELETE FROM phrases WHERE group_id=?", (group_id,))
    conn.execute("DELETE FROM groups WHERE id=?", (group_id,))
    conn.commit()
    conn.close()


# ============================================================
# Phrases
# ============================================================

def add_phrase(group_id: int, title: str = "", content: str = "", db_path: str = DB_PATH) -> int:
    conn = get_connection(db_path)
    cur = conn.execute(
        "INSERT INTO phrases(group_id, title, content, sort_order) VALUES(?,?,?,"
        "(SELECT COALESCE(MAX(sort_order),0)+1 FROM phrases WHERE group_id=?))",
        (group_id, title, content, group_id)
    )
    conn.commit()
    new_id = cur.lastrowid
    conn.close()
    return new_id


def get_phrases(group_id: int, search: str = None, pinned_only: bool = False,
                limit: int = 500, db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    if search and len(search) >= 2:
        rows = conn.execute(
            """SELECT p.* FROM phrases_fts f
               JOIN phrases p ON p.id = f.rowid
               WHERE phrases_fts MATCH ?
               ORDER BY p.is_pinned DESC, p.use_count DESC, p.sort_order
               LIMIT ?""",
            (search, limit)
        ).fetchall()
    elif pinned_only:
        rows = conn.execute(
            """SELECT * FROM phrases WHERE is_pinned=1
               ORDER BY use_count DESC LIMIT ?""",
            (limit,)
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT * FROM phrases WHERE group_id=?
               ORDER BY is_pinned DESC, sort_order, id LIMIT ?""",
            (group_id, limit)
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_phrase(phrase_id: int, title: str = None, content: str = None, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    if title is not None:
        conn.execute("UPDATE phrases SET title=? WHERE id=?", (title, phrase_id))
    if content is not None:
        conn.execute("UPDATE phrases SET content=? WHERE id=?", (content, phrase_id))
    conn.commit()
    conn.close()


def delete_phrase(phrase_id: int, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM phrases WHERE id=?", (phrase_id,))
    conn.commit()
    conn.close()


def toggle_phrase_pin(phrase_id: int, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE phrases SET is_pinned=CASE WHEN is_pinned=1 THEN 0 ELSE 1 END WHERE id=?",
        (phrase_id,)
    )
    conn.commit()
    conn.close()


def record_phrase_use(phrase_id: int, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE phrases SET use_count=use_count+1 WHERE id=?", (phrase_id,)
    )
    conn.commit()
    conn.close()


def move_phrase(phrase_id: int, new_group_id: int, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute("UPDATE phrases SET group_id=? WHERE id=?", (new_group_id, phrase_id))
    conn.commit()
    conn.close()


# ============================================================
# Settings
# ============================================================

def get_setting(key: str, default: str = "", db_path: str = DB_PATH) -> str:
    conn = get_connection(db_path)
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str, db_path: str = DB_PATH):
    conn = get_connection(db_path)
    conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?,?)", (key, value))
    conn.commit()
    conn.close()
