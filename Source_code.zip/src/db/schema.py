"""
短语管理器数据库 Schema
分组树 + 短语 + 设置
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "phrases.db")

CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS groups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL DEFAULT 'Unnamed',
    parent_id   INTEGER REFERENCES groups(id) ON DELETE CASCADE,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS phrases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    title       TEXT    NOT NULL DEFAULT '',
    content     TEXT    NOT NULL DEFAULT '',
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    use_count   INTEGER NOT NULL DEFAULT 0,
    is_pinned   INTEGER NOT NULL DEFAULT 0
);

CREATE VIRTUAL TABLE IF NOT EXISTS phrases_fts USING fts5(
    title, content, content='phrases', content_rowid='id',
    tokenize='unicode61'
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_groups_parent ON groups(parent_id);
CREATE INDEX IF NOT EXISTS idx_phrases_group ON phrases(group_id);
CREATE INDEX IF NOT EXISTS idx_phrases_sort  ON phrases(sort_order);
CREATE INDEX IF NOT EXISTS idx_phrases_pin   ON phrases(is_pinned);
"""

TRIGGERS_SQL = """
CREATE TRIGGER IF NOT EXISTS phrases_ai AFTER INSERT ON phrases BEGIN
    INSERT INTO phrases_fts(rowid, title, content) VALUES (new.id, new.title, new.content);
END;
CREATE TRIGGER IF NOT EXISTS phrases_ad AFTER DELETE ON phrases BEGIN
    INSERT INTO phrases_fts(phrases_fts, rowid, title, content) VALUES('delete', old.id, old.title, old.content);
END;
CREATE TRIGGER IF NOT EXISTS phrases_au AFTER UPDATE ON phrases BEGIN
    INSERT INTO phrases_fts(phrases_fts, rowid, title, content) VALUES('delete', old.id, old.title, old.content);
    INSERT INTO phrases_fts(rowid, title, content) VALUES (new.id, new.title, new.content);
END;
"""

DEFAULT_SETTINGS = {
    "hotkey": "Alt+V",
    "theme": "dark",
    "max_phrase_length": "5000",
    "close_behavior": "quit",
}


def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: str = DB_PATH) -> sqlite3.Connection:
    conn = get_connection(db_path)
    conn.executescript(CREATE_TABLES_SQL)
    conn.executescript(TRIGGERS_SQL)
    for key, val in DEFAULT_SETTINGS.items():
        conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)", (key, val))
    conn.commit()
    return conn
