"""
快捷键弹窗 —— 按快捷键后在鼠标位置弹出小浮窗
分组树（自定义三角箭头），短语列表，点击短语 → 粘贴并关闭
"""
import time

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel,
    QListWidget, QListWidgetItem, QAbstractItemView, QTreeWidget,
    QTreeWidgetItem, QApplication,
)
from PyQt5.QtCore import Qt, pyqtSignal, QSize, QPoint
from PyQt5.QtGui import QCursor, QFont

from src.db import models
from src.locale import t
from src.gui import themes


def _short(text: str, max_len: int = 50) -> str:
    if not text: return ""
    t2 = text.replace("\n", " ").replace("\r", "")
    return t2[:max_len] + ("..." if len(t2) > max_len else "")


class PopupWindow(QWidget):
    phrase_selected = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._setup_ui()
        self._expanded_state = {}
        self._last_group_id = None

    def _setup_ui(self):
        self.setWindowTitle(t("popup_title"))
        self.setMinimumSize(300, 120)
        self.resize(520, 360)
        self.setWindowFlags(Qt.Popup | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(themes.get_popup_qss())
        themes.on_theme_change(lambda _: self.setStyleSheet(themes.get_popup_qss()))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(2)
        splitter = QSplitter(Qt.Horizontal)

        self._tree = QTreeWidget()
        self._tree.setHeaderHidden(True)
        self._tree.setIndentation(0)
        self._tree.setAnimated(True)
        self._tree.setMouseTracking(True)
        self._tree.itemEntered.connect(self._on_tree_hovered)
        self._tree.itemClicked.connect(self._on_tree_clicked)
        self._tree.itemExpanded.connect(self._on_item_toggled)
        self._tree.itemCollapsed.connect(self._on_item_toggled)
        self._tree.setFixedWidth(170)
        splitter.addWidget(self._tree)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(2, 2, 2, 2)
        rl.setSpacing(2)
        rl.addWidget(QLabel(t("search_placeholder")))
        # 存放所有列的横向容器
        self._cols_layout = QHBoxLayout()
        self._cols_layout.setSpacing(2)
        rl.addLayout(self._cols_layout, 1)
        # 主列
        self._phrase_list = QListWidget()
        self._phrase_list.itemClicked.connect(self._on_phrase_clicked)
        self._cols_layout.addWidget(self._phrase_list, 1)
        splitter.addWidget(right)
        splitter.setSizes([170, 326])
        layout.addWidget(splitter)

    # ============================================================
    def _find_first_with_phrases(self, groups):
        """递归找第一个有短语的分组 ID"""
        for g in groups:
            phrases = models.get_phrases(g["id"], limit=1)
            if len(phrases) > 0:
                return g["id"]
            result = self._find_first_with_phrases(g.get("children", []))
            if result:
                return result
        return None

    def show_at_cursor(self):
        self._load_groups()
        self._refresh_tree()
        target_gid = self._last_group_id or self._find_first_with_phrases(self._tree_data)
        self._apply_size()  # 先设初始大小
        if target_gid:
            self._select_tree_item(target_gid)
            self._refresh_phrases(target_gid)  # 后根据内容调整
        pos = QCursor.pos()
        screen = QApplication.primaryScreen().availableGeometry()
        x = min(pos.x(), screen.right() - self.width())
        y = pos.y() - self.height()
        if y < screen.top():
            y = screen.top()
        self.move(QPoint(max(screen.left(), x), y))
        self.show()
        self.activateWindow()

    def _load_groups(self):
        flat = models.get_all_groups()
        self._tree_data = models.build_group_tree(flat)
        saved = models.get_setting("popup_expanded", "")
        self._expanded_state = {}
        if saved:
            for pair in saved.split(","):
                if ":" in pair:
                    gid, state = pair.split(":")
                    self._expanded_state[int(gid)] = (state == "1")

    # ============================================================
    # 树（自定义三角箭头）
    # ============================================================

    def _refresh_tree(self):
        self._tree.blockSignals(True)
        self._tree.clear()
        for g in self._tree_data:
            self._add_tree_node(self._tree, g, 0)
        self._tree.blockSignals(False)

    def _add_tree_node(self, parent, group: dict, depth: int):
        item = QTreeWidgetItem(parent)
        gid = group["id"]
        children = group.get("children", [])
        has_kids = len(children) > 0

        if gid not in self._expanded_state:
            self._expanded_state[gid] = True
        expanded = self._expanded_state[gid]

        # 自定义箭头 + 缩进 + 名称
        prefix = "  " * depth
        arrow = "▾ " if (has_kids and expanded) else ("▸ " if has_kids else "  ")
        name = group.get("name", "Unnamed")
        item.setText(0, f"{prefix}{arrow}{name}")

        # 根分组：大字号加粗  |  子分组：小字号
        font = QFont()
        if depth == 0:
            font.setPointSize(11)
            font.setBold(True)
        else:
            font.setPointSize(10)
            font.setBold(False)
        item.setFont(0, font)

        item.setData(0, Qt.UserRole, gid)
        item.setData(0, Qt.UserRole + 1, name)  # 原始名称
        item.setData(0, Qt.UserRole + 2, has_kids)
        item.setData(0, Qt.UserRole + 3, depth)

        for child in children:
            self._add_tree_node(item, child, depth + 1)

        item.setExpanded(expanded)
        return item

    def _update_arrow(self, item):
        """更新单个 item 的箭头符号"""
        name = item.data(0, Qt.UserRole + 1) or item.text(0)
        has_kids = item.data(0, Qt.UserRole + 2)
        depth = item.data(0, Qt.UserRole + 3) or 0
        gid = item.data(0, Qt.UserRole)
        expanded = self._expanded_state.get(gid, True)
        prefix = "  " * depth
        arrow = "▾ " if (has_kids and expanded) else ("▸ " if has_kids else "  ")
        item.setText(0, f"{prefix}{arrow}{name}")

    def _on_item_toggled(self, item):
        gid = item.data(0, Qt.UserRole)
        self._expanded_state[gid] = item.isExpanded()
        self._update_arrow(item)
        self._save_expanded()

    def _save_expanded(self):
        parts = [f"{gid}:{1 if v else 0}" for gid, v in self._expanded_state.items()]
        models.set_setting("popup_expanded", ",".join(parts))

    # ============================================================
    # 短语
    # ============================================================

    def _select_tree_item(self, gid):
        """在树中选中指定 ID 的项"""
        def _find(item):
            if item.data(0, Qt.UserRole) == gid:
                return item
            for i in range(item.childCount()):
                found = _find(item.child(i))
                if found: return found
            return None
        for i in range(self._tree.topLevelItemCount()):
            found = _find(self._tree.topLevelItem(i))
            if found:
                self._tree.setCurrentItem(found)
                return

    def _on_tree_hovered(self, item, col):
        gid = item.data(0, Qt.UserRole)
        self._refresh_phrases(gid)
        self._last_group_id = gid

    def _on_tree_clicked(self, item, col):
        # 有子分组 = 单击展开/收起  |  无子分组 = 显示短语
        if item.data(0, Qt.UserRole + 2):  # has_kids
            item.setExpanded(not item.isExpanded())
        else:
            gid = item.data(0, Qt.UserRole)
            self._refresh_phrases(gid)
            self._last_group_id = gid

    def _refresh_phrases(self, group_id: int):
        self._phrase_list.clear()
        phrases = models.get_phrases(group_id, limit=100)
        for p in phrases:
            text = p["title"] or _short(p["content"], 40)
            if p["is_pinned"]: text = "📌 " + text
            it = QListWidgetItem(text)
            it.setData(Qt.UserRole, p["id"])
            it.setData(Qt.UserRole+1, p["content"])
            it.setSizeHint(QSize(0, 30))
            self._phrase_list.addItem(it)
        self._adjust_for_content(len(phrases))

    # ============================================================
    # 自适应大小
    # ============================================================

    def _apply_size(self):
        from src.db.models import get_setting
        if get_setting("popup_size", "fixed") == "auto":
            self.setMinimumSize(300, 120)
            self.setMaximumSize(16777215, 16777215)
            self._phrase_list.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        else:
            self.setFixedSize(520, 360)
            self._phrase_list.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

    def _adjust_for_content(self, phrase_count: int):
        from src.db.models import get_setting
        if get_setting("popup_size", "fixed") != "auto":
            return
        if phrase_count == 0:
            self._use_single_column(); self.resize(520, 120); return

        item_h, header_h = 32, 40
        screen = QApplication.primaryScreen().availableGeometry()
        cursor_pos = QCursor.pos()
        avail_h = max(120, cursor_pos.y() - screen.top() - 10)
        per_col = max(1, (avail_h - header_h) // item_h)
        total_cols_needed = (phrase_count + per_col - 1) // per_col

        if total_cols_needed <= 1:
            self._use_single_column()
            self.resize(520, max(120, header_h + phrase_count * item_h))
            return

        # 能并排放下多少列
        avail_w = max(200, screen.right() - cursor_pos.x() - 20)
        col_w = min(180, (avail_w - 10) // total_cols_needed)
        fit_cols = max(1, avail_w // (col_w + 4))

        if total_cols_needed <= fit_cols:
            # 全部塞得下，每列填满 per_col，最后一列剩余
            self._setup_columns(total_cols_needed, per_col, col_w)
            last_items = phrase_count - (total_cols_needed - 1) * per_col
            h = header_h + max(per_col, last_items) * item_h + 10
            self.resize(180 + total_cols_needed * (col_w + 4), h)
        else:
            # 放不下，前 fit_cols-1 列填满，最后一列滚轮
            self._setup_columns(fit_cols - 1, per_col, col_w)
            remaining = phrase_count - (fit_cols - 1) * per_col
            self._add_scrollable_col(fit_cols - 1, remaining, per_col, col_w)
            self.resize(180 + fit_cols * (col_w + 4), header_h + per_col * item_h + 10)

    def _use_single_column(self):
        layout = self._cols_layout
        while layout.count() > 1:
            w = layout.itemAt(layout.count() - 1).widget()
            if w: layout.removeWidget(w); w.deleteLater()
            else: break

    def _setup_columns(self, num_cols, per_col, col_w=170):
        layout = self._cols_layout
        all_p = [{"t": self._phrase_list.item(i).text(), "id": self._phrase_list.item(i).data(Qt.UserRole), "c": self._phrase_list.item(i).data(Qt.UserRole+1)} for i in range(self._phrase_list.count())]
        while layout.count() > 1:
            w = layout.itemAt(layout.count() - 1).widget()
            if w: layout.removeWidget(w); w.deleteLater()
            else: break
        self._phrase_list.clear(); self._phrase_list.setFixedWidth(col_w)
        for p in all_p[:per_col]:
            it = QListWidgetItem(p["t"]); it.setData(Qt.UserRole, p["id"]); it.setData(Qt.UserRole+1, p["c"]); it.setSizeHint(QSize(0, 30))
            self._phrase_list.addItem(it)
        for ci in range(1, num_cols):
            lst = QListWidget(); lst.setStyleSheet(self._phrase_list.styleSheet()); lst.itemClicked.connect(self._on_phrase_clicked)
            lst.setFixedWidth(col_w); lst.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            for p in all_p[ci*per_col:(ci+1)*per_col]:
                it = QListWidgetItem(p["t"]); it.setData(Qt.UserRole, p["id"]); it.setData(Qt.UserRole+1, p["c"]); it.setSizeHint(QSize(0, 30))
                lst.addItem(it)
            layout.addWidget(lst)

    def _add_scrollable_col(self, filled_cols, remaining, per_col, col_w):
        layout = self._cols_layout
        all_p = [{"t": self._phrase_list.item(i).text(), "id": self._phrase_list.item(i).data(Qt.UserRole), "c": self._phrase_list.item(i).data(Qt.UserRole+1)} for i in range(self._phrase_list.count())]
        lst = QListWidget(); lst.setStyleSheet(self._phrase_list.styleSheet()); lst.itemClicked.connect(self._on_phrase_clicked)
        lst.setFixedWidth(col_w); lst.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        for p in all_p[filled_cols*per_col:filled_cols*per_col+remaining]:
            it = QListWidgetItem(p["t"]); it.setData(Qt.UserRole, p["id"]); it.setData(Qt.UserRole+1, p["c"]); it.setSizeHint(QSize(0, 30))
            lst.addItem(it)
        layout.addWidget(lst)

    def _on_phrase_clicked(self, item):
        content = item.data(Qt.UserRole+1)
        if content:
            self.hide()
            self._paste_text(content)

    def _paste_text(self, text: str):
        import pyperclip
        pyperclip.copy(text)
        try:
            import keyboard
            keyboard.send("ctrl+v")
        except Exception:
            pass

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(event)
