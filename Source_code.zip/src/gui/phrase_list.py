"""
短语列表组件 —— 显示当前分组下的短语，支持添加/编辑/删除/粘贴
"""
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QTextEdit, QMenu, QAction,
    QAbstractItemView, QDialog, QFormLayout, QSizePolicy, QLineEdit,
)
from PyQt5.QtCore import Qt, pyqtSignal, QSize
import html as html_mod

from src.locale import t
from src.gui import themes


def _escape(text: str, max_len: int = 80) -> str:
    if not text:
        return t("phrase_empty")
    t2 = text.replace("\n", " ⏎ ").replace("\r", "")
    if len(t2) > max_len:
        t2 = t2[:max_len] + "…"
    return html_mod.escape(t2)


class PhraseEditDialog(QDialog):
    """添加/编辑短语对话框"""
    def __init__(self, parent=None, title="", content="", mode="add"):
        super().__init__(parent)
        self.setStyleSheet("")  # 先清空继承的样式
        self.setWindowTitle(t("dlg_add_title") if mode == "add" else t("dlg_edit_title"))
        self.setMinimumSize(420, 280)
        self.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        self.setStyleSheet(themes.get_dialog_qss())

        layout = QFormLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 14, 16, 14)

        self._title_edit = QLineEdit()
        self._title_edit.setContextMenuPolicy(Qt.NoContextMenu)
        self._title_edit.setPlaceholderText(t("phrase_title_placeholder"))
        self._title_edit.setText(title)
        layout.addRow(QLabel(t("dlg_title_label")), self._title_edit)

        self._content_edit = QTextEdit()
        self._content_edit.setContextMenuPolicy(Qt.NoContextMenu)
        self._content_edit.setPlaceholderText(t("phrase_content_placeholder"))
        self._content_edit.setText(content)
        layout.addRow(QLabel(t("dlg_content_label")), self._content_edit)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton(t("btn_cancel"))
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton(t("btn_save"))
        save_btn.clicked.connect(self.accept)
        save_btn.setStyleSheet("QPushButton{background-color:#e94560;} QPushButton:hover{background-color:#ff6b81;}")
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addRow(btn_row)

    @property
    def phrase_title(self) -> str:
        return self._title_edit.text().strip()

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        widget = self.focusWidget()
        if isinstance(widget, QLineEdit):
            menu.addAction("撤销\tCtrl+Z", widget.undo)
            menu.addSeparator()
            menu.addAction("剪切\tCtrl+X", widget.cut)
            menu.addAction("复制\tCtrl+C", widget.copy)
            menu.addAction("粘贴\tCtrl+V", widget.paste)
            if hasattr(widget, 'del_'):
                menu.addAction("删除\tDel", widget.del_)
            menu.addSeparator()
            menu.addAction("全选\tCtrl+A", widget.selectAll)
        elif isinstance(widget, QTextEdit):
            menu.addAction("撤销\tCtrl+Z", widget.undo)
            menu.addSeparator()
            menu.addAction("剪切\tCtrl+X", widget.cut)
            menu.addAction("复制\tCtrl+C", widget.copy)
            menu.addAction("粘贴\tCtrl+V", widget.paste)
            menu.addSeparator()
            menu.addAction("全选\tCtrl+A", widget.selectAll)
        menu.exec_(event.globalPos())

    @property
    def phrase_content(self) -> str:
        return self._content_edit.toPlainText()


class PhraseListWidget(QWidget):
    """短语列表面板"""
    phrase_paste = pyqtSignal(int)
    phrase_edited = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._current_group_id = 1
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # 短语列表
        self._list = QListWidget()
        self._list.setSelectionMode(QAbstractItemView.SingleSelection)
        self._list.setContextMenuPolicy(Qt.CustomContextMenu)
        self._list.customContextMenuRequested.connect(self._on_context_menu)
        self._list.itemDoubleClicked.connect(self._on_edit_phrase)
        layout.addWidget(self._list, 1)

    def set_group(self, group_id: int):
        self._current_group_id = group_id
        self.refresh()

    def refresh(self):
        from src.db.models import get_phrases
        self._list.clear()
        phrases = get_phrases(self._current_group_id)
        for p in phrases:
            item = QListWidgetItem()
            text = p["title"] or _escape(p["content"], 60)
            if p["is_pinned"]:
                text = "📌 " + text
            item.setText(text)
            item.setData(Qt.UserRole, p["id"])
            item.setSizeHint(QSize(0, 36))
            self._list.addItem(item)

    def search(self, query: str):
        from src.db.models import get_phrases
        self._list.clear()
        if len(query) < 2:
            return self.refresh()
        phrases = get_phrases(self._current_group_id, search=query)
        for p in phrases:
            item = QListWidgetItem()
            text = p["title"] or _escape(p["content"], 60)
            if p["is_pinned"]:
                text = "📌 " + text
            item.setText(text)
            item.setData(Qt.UserRole, p["id"])
            item.setSizeHint(QSize(0, 36))
            self._list.addItem(item)

    def _on_add(self):
        dlg = PhraseEditDialog(self, mode="add")
        self.window()._suppress_autohide = True
        result = dlg.exec_()
        self.window()._suppress_autohide = False
        if result == QDialog.Accepted and dlg.phrase_content.strip():
            from src.db.models import add_phrase
            add_phrase(self._current_group_id, dlg.phrase_title, dlg.phrase_content)
            self.refresh()
            self.phrase_edited.emit()

    def _on_edit_phrase(self, item):
        """双击编辑短语"""
        pid = item.data(Qt.UserRole)
        if not pid:
            return
        from src.db.models import get_phrases, update_phrase
        phrases = get_phrases(self._current_group_id)
        phrase = next((p for p in phrases if p["id"] == pid), None)
        if not phrase:
            return
        dlg = PhraseEditDialog(self, phrase["title"], phrase["content"], "edit")
        self.window()._suppress_autohide = True
        result = dlg.exec_()
        self.window()._suppress_autohide = False
        if result == QDialog.Accepted:
            update_phrase(pid, dlg.phrase_title, dlg.phrase_content)
            self.refresh()
            self.phrase_edited.emit()

    def _on_context_menu(self, pos):
        item = self._list.itemAt(pos)
        if not item:
            return
        pid = item.data(Qt.UserRole)

        from src.db.models import get_phrases, update_phrase, delete_phrase, toggle_phrase_pin
        # find the phrase data
        phrases = get_phrases(self._current_group_id)
        phrase = next((p for p in phrases if p["id"] == pid), None)
        if not phrase:
            return

        menu = QMenu(self)

        edit_a = menu.addAction(f"✏️ {t('phrase_edit')}")
        pin_a = menu.addAction(f"📌 {t('phrase_unpin') if phrase['is_pinned'] else t('phrase_pin')}")
        del_a = menu.addAction(f"🗑️ {t('phrase_delete')}")

        action = menu.exec_(self._list.viewport().mapToGlobal(pos))

        if action == edit_a:
            dlg = PhraseEditDialog(self, phrase["title"], phrase["content"], "edit")
            self.window()._suppress_autohide = True
            result = dlg.exec_()
            self.window()._suppress_autohide = False
            if result == QDialog.Accepted:
                update_phrase(pid, dlg.phrase_title, dlg.phrase_content)
                self.refresh()
                self.phrase_edited.emit()
        elif action == pin_a:
            toggle_phrase_pin(pid)
            self.refresh()
        elif action == del_a:
            delete_phrase(pid)
            self.refresh()
            self.phrase_edited.emit()
