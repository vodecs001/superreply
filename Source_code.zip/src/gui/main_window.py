"""
主窗口 —— 短语管理界面
左侧分组树 + 右侧短语列表 + 底部快捷键提示
"""
import os, sys, webbrowser
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QLineEdit, QPushButton, QStatusBar, QLabel, QApplication,
    QToolBar, QAction, QDialog, QFormLayout, QDialogButtonBox, QMenu, QFileDialog, QMessageBox,
    QRadioButton, QButtonGroup,
)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QEvent
from PyQt5.QtGui import QIcon

from src.db import schema, models
from src.gui import themes
from src.gui.group_tree import GroupTree
from src.gui.phrase_list import PhraseListWidget
from src.locale import t


class MainWindow(QMainWindow):
    show_requested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._db_path = schema.DB_PATH
        schema.init_db(self._db_path)

        self.setWindowTitle(t("app_title"))
        self.setWindowIcon(QIcon(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "icon", "icon.png")))
        self.setMinimumSize(720, 500)
        self.resize(920, 620)
        self.setWindowFlags(
            Qt.Window | Qt.FramelessWindowHint
        )
        self.setStyleSheet(themes.get_current_qss())
        themes.on_theme_change(lambda qss: self.setStyleSheet(qss))
        themes.load_theme()

        self._setup_ui()
        self._refresh_groups()
        self._center_on_screen()

        # 防止子对话框触发自动隐藏
        self._suppress_autohide = False

        # 加载快捷键设置
        self._hotkey_callback = None

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # --- 标题栏 ---
        main_layout.addWidget(self._create_title_bar())

        # --- 工具栏 ---
        toolbar = QHBoxLayout()
        toolbar.setSpacing(4)
        def _tb_btn(text):
            b = QPushButton(text)
            b.setFixedHeight(26)
            b.setStyleSheet("QPushButton{background-color:#0f3460;border:1px solid #2a2a4a;border-radius:0;padding:4px 12px;color:#fff;font-size:13px;font-weight:bold;}QPushButton:hover{background-color:#e94560;}")
            return b
        self._theme_btn = _tb_btn("🎨 日间/夜间模式切换")
        self._theme_btn.clicked.connect(self._show_theme_menu)
        toolbar.addWidget(self._theme_btn)
        export_btn = _tb_btn("📤 导出")
        export_btn.clicked.connect(self._export_data)
        toolbar.addWidget(export_btn)
        import_btn = _tb_btn("📥 导入")
        import_btn.clicked.connect(self._import_data)
        toolbar.addWidget(import_btn)
        toolbar.addStretch()
        settings_btn = _tb_btn("⚙️ 设置")
        settings_btn.clicked.connect(self._show_settings_dialog)
        toolbar.addWidget(settings_btn)
        # GitHub
        git_btn = _tb_btn("🐙 GitHub")
        git_btn.clicked.connect(lambda: webbrowser.open("https://github.com/vodecs001/superreply"))
        toolbar.addWidget(git_btn)
        help_btn = _tb_btn("❓ 帮助")
        help_btn.clicked.connect(self._show_help_menu)
        toolbar.addWidget(help_btn)
        main_layout.addLayout(toolbar)

        # --- 搜索行 ---
        search_row = QHBoxLayout()
        search_row.setSpacing(8)
        add_group_btn = QPushButton(f"➕ {t('group_new_root')}")
        add_group_btn.setFixedHeight(32)
        add_group_btn.setStyleSheet("QPushButton{background-color:#0f3460;border:1px solid #2a2a4a;border-radius:0;padding:5px 14px;color:#eee;}QPushButton:hover{background-color:#e94560;}")
        add_group_btn.clicked.connect(lambda: self._group_tree._add_group_flow(None))
        search_row.addWidget(add_group_btn)
        self._search_bar = QLineEdit()
        self._search_bar.setPlaceholderText(f"🔍  {t('search_placeholder')}")
        self._search_bar.textChanged.connect(self._on_search)
        search_row.addWidget(self._search_bar, 1)
        main_layout.addLayout(search_row)

        # --- 主内容 ---
        splitter = QSplitter(Qt.Horizontal)

        self._group_tree = GroupTree()
        self._group_tree.group_selected.connect(self._on_group_selected)
        splitter.addWidget(self._group_tree)

        self._phrase_list = PhraseListWidget()
        self._phrase_list.phrase_paste.connect(self._on_phrase_paste)
        self._phrase_list.phrase_edited.connect(self._refresh_groups)
        splitter.addWidget(self._phrase_list)

        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        splitter.setSizes([200, 720])
        main_layout.addWidget(splitter, 1)

        # --- 底部状态栏 ---
        bottom = QHBoxLayout()
        bottom.setContentsMargins(8, 4, 8, 4)

        self._status_bar = QStatusBar()
        self._status_bar.showMessage(t("status_ready"))
        bottom.addWidget(self._status_bar, 1)

        # 快捷键按钮
        hotkey_val = models.get_setting("hotkey", "Ctrl+Shift+Q", self._db_path)
        self._hotkey_btn = QPushButton(f"⌨ {t('btn_hotkey')}: {hotkey_val}")
        self._hotkey_btn.setStyleSheet(
            "QPushButton{background-color:#0f3460; border-radius:4px; padding:4px 10px; color:#ccc; font-size:11px;}"
            "QPushButton:hover{color:#fff;}"
        )
        self._hotkey_btn.clicked.connect(self._show_hotkey_setting)
        bottom.addWidget(self._hotkey_btn)

        main_layout.addLayout(bottom)

        self._search_bar.setFocus()

    def _create_title_bar(self) -> QWidget:
        bar = QWidget()
        bar.setFixedHeight(36)
        bar.setStyleSheet(
            "background-color:#16213e;"
        )
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(12, 0, 8, 0)

        title = QLabel(t("app_short"))
        title.setStyleSheet("font-weight:bold; font-size:15px; background:transparent; color:#e94560;")
        layout.addWidget(title)

        # 中间作者信息
        center_label = QLabel("作者：执简 | 联系方式请看【帮助-关于作者】")
        center_label.setStyleSheet("font-size:12px; background:transparent; color:#888;font-weight:bold;")
        center_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(center_label, 1)

        layout.addStretch()

        min_btn = QPushButton("─")
        min_btn.setFixedSize(28, 24)
        min_btn.setStyleSheet(
            "QPushButton{background:transparent; border:none; color:#a0a0b0; font-size:16px;}"
            "QPushButton:hover{color:#eee;}"
        )
        min_btn.clicked.connect(self.showMinimized)

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(28, 24)
        close_btn.setStyleSheet(
            "QPushButton{background:transparent; border:none; color:#a0a0b0; font-size:14px;}"
            "QPushButton:hover{background-color:#e94560; color:#fff;}"
        )
        close_btn.clicked.connect(self.close)

        layout.addWidget(min_btn)
        layout.addWidget(close_btn)

        bar.mousePressEvent = self._title_bar_press
        bar.mouseMoveEvent = self._title_bar_move
        self._drag_pos = None
        return bar

    def _title_bar_press(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.globalPos() - self.frameGeometry().topLeft()

    def _title_bar_move(self, event):
        if event.buttons() == Qt.LeftButton and self._drag_pos is not None:
            self.move(event.globalPos() - self._drag_pos)

    def _center_on_screen(self):
        screen = QApplication.primaryScreen().availableGeometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)

    # ============================================================
    # 分组 / 短语
    # ============================================================

    def _refresh_groups(self):
        # 保存当前选中的分组
        current = self._group_tree.currentItem()
        current_gid = current.data(0, Qt.UserRole) if current else None

        flat = models.get_all_groups(self._db_path)
        tree = models.build_group_tree(flat)
        self._group_tree.load_groups(tree)

        # 恢复选中
        if current_gid:
            self._group_tree._restore_selection(current_gid)

    def _on_group_selected(self, group_id: int, name: str):
        self._phrase_list.set_group(group_id)

    def _update_total_count(self):
        pass

    def _on_search(self, text: str):
        if len(text) >= 2:
            self._phrase_list.search(text)
        elif len(text) == 0:
            self._phrase_list.refresh()

    def _on_phrase_paste(self, phrase_id: int):
        phrases = models.get_phrases(self._phrase_list._current_group_id)
        phrase = next((p for p in phrases if p["id"] == phrase_id), None)
        if phrase:
            models.record_phrase_use(phrase_id, self._db_path)
            self._do_paste(phrase["content"])

    def _do_paste(self, text: str):
        import pyperclip
        pyperclip.copy(text)
        self.hide()
        try:
            import keyboard
            keyboard.send("ctrl+v")
        except Exception:
            pass

    # ============================================================
    # 快捷键设置
    # ============================================================

    def _show_hotkey_setting(self):
        current = models.get_setting("hotkey", "Ctrl+Shift+V", self._db_path)

        dlg = QDialog(self)
        dlg.setWindowTitle(t("settings_title"))
        dlg.setFixedSize(380, 210)
        dlg.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        dlg.setStyleSheet(themes.get_dialog_qss())

        layout = QFormLayout(dlg)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 16, 20, 16)

        info = QLabel(t("settings_hotkey_hint"))
        info.setStyleSheet("font-size:10px; color:#888;")
        layout.addRow(QLabel(t("settings_hotkey")), info)

        hotkey_input = QLineEdit(current)
        hotkey_input.setAlignment(Qt.AlignCenter)
        hotkey_input.setPlaceholderText("DOUBLECTRL / Ctrl+V / F1 …")
        layout.addRow(hotkey_input)

        # 提示
        hint = QLabel("点击输入框后直接按组合键捕获")
        hint.setStyleSheet("font-size:9px; color:#666;")
        layout.addRow(hint)

        # 键盘捕获
        def capture_key(event):
            parts = []
            if event.modifiers() & Qt.ControlModifier: parts.append("Ctrl")
            if event.modifiers() & Qt.ShiftModifier: parts.append("Shift")
            if event.modifiers() & Qt.AltModifier: parts.append("Alt")
            key = event.key()
            if key not in (Qt.Key_Control, Qt.Key_Shift, Qt.Key_Alt, Qt.Key_Meta):
                from PyQt5.QtGui import QKeySequence
                key_str = QKeySequence(key).toString()
                if key_str: parts.append(key_str)
            if parts:
                hotkey_input.setText("+".join(parts))

        hotkey_input.keyPressEvent = capture_key

        # 鼠标捕获：中键/侧键按下时捕获
        def capture_mouse(event):
            btn = event.button()
            parts = []
            if QApplication.keyboardModifiers() & Qt.ControlModifier: parts.append("Ctrl")
            if QApplication.keyboardModifiers() & Qt.ShiftModifier: parts.append("Shift")
            if QApplication.keyboardModifiers() & Qt.AltModifier: parts.append("Alt")

            if btn == Qt.MiddleButton:
                parts.append("MIDDLEBUTTON")
            elif btn == Qt.XButton1:
                parts.append("XBUTTON1")
            elif btn == Qt.XButton2:
                parts.append("XBUTTON2")
            else:
                return  # 左右键忽略

            hotkey_input.setText("+".join(parts))

        hotkey_input.mousePressEvent = capture_mouse

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton(t("btn_cancel"))
        cancel_btn.clicked.connect(dlg.reject)
        save_btn = QPushButton(t("btn_save"))
        save_btn.clicked.connect(dlg.accept)
        save_btn.setStyleSheet("QPushButton{background-color:#e94560;} QPushButton:hover{background-color:#ff6b81;}")
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addRow(btn_row)

        self._suppress_autohide = True
        if dlg.exec_() == QDialog.Accepted and hotkey_input.text().strip():
            new_hotkey = hotkey_input.text().strip()
            models.set_setting("hotkey", new_hotkey, self._db_path)
            self._hotkey_btn.setText(f"⌨ {t('btn_hotkey')}: {new_hotkey}")
            if self._hotkey_callback:
                self._hotkey_callback(new_hotkey)
        self._suppress_autohide = False

    def set_hotkey_callback(self, cb):
        self._hotkey_callback = cb

    # ============================================================
    # 窗口行为
    # ============================================================

    def showEvent(self, event):
        """确保窗口在任务栏显示"""
        super().showEvent(event)
        try:
            import ctypes
            GWL_EXSTYLE = -20
            WS_EX_APPWINDOW = 0x00040000
            hwnd = int(self.winId())
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE,
                ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE) | WS_EX_APPWINDOW)
        except Exception:
            pass

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.hide()
            return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        behavior = models.get_setting("close_behavior", "quit", self._db_path)
        if behavior == "tray":
            event.ignore()
            self.hide()
        else:
            event.accept()
            QApplication.instance().quit()

    def _show_theme_menu(self):
        menu = QMenu(self)
        dark_a = menu.addAction("🌙 夜间模式")
        light_a = menu.addAction("☀️ 日间模式")
        follow_a = menu.addAction("🔄 跟随系统")
        action = menu.exec_(self._theme_btn.mapToGlobal(self._theme_btn.rect().bottomLeft()))
        if action == dark_a:
            themes.set_theme("dark"); themes.save_theme("dark")
        elif action == light_a:
            themes.set_theme("light"); themes.save_theme("light")
        elif action == follow_a:
            themes.set_theme("follow"); themes.save_theme("follow")

    # ============================================================
    # 导出 / 导入 / 帮助
    # ============================================================

    def _export_data(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出快捷短语", "phrases_backup.json", "JSON (*.json)")
        if path:
            themes.export_phrases(path)
            QMessageBox.information(self, "导出成功", f"已导出到:\n{path}")

    def _import_data(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入快捷短语", "", "JSON (*.json)")
        if path:
            count = themes.import_phrases(path)
            self._refresh_groups()
            self._phrase_list.refresh()
            QMessageBox.information(self, "导入成功", f"已导入 {count} 条短语")

    def _show_help_menu(self):
        menu = QMenu(self)
        about_a = menu.addAction("关于作者")
        action = menu.exec_(self.sender().mapToGlobal(self.sender().rect().bottomLeft()))
        if action == about_a:
            self._show_about()

    def _show_about(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("关于作者")
        dlg.setMinimumSize(600, 350)
        dlg.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        dlg.setStyleSheet(themes.get_dialog_qss())
        layout = QVBoxLayout(dlg)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 12, 16, 12)
        title = QLabel("超级回复 (Super Reply)")
        title.setStyleSheet("font-size:14px;font-weight:bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        author = QLabel("作者：执简")
        author.setAlignment(Qt.AlignCenter)
        author.setStyleSheet("font-size:12px;")
        layout.addWidget(author)
        import os
        app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0]))))
        img1 = os.path.join(app_dir, "Contact_Information", "lxfs.jpg")
        img2 = os.path.join(app_dir, "Contact_Information", "zs.jpg")
        has1 = os.path.exists(img1)
        has2 = os.path.exists(img2)
        if has1 or has2:
            from PyQt5.QtGui import QPixmap
            img_row = QHBoxLayout()
            for path in [img1, img2]:
                if os.path.exists(path):
                    lbl = QLabel()
                    pix = QPixmap(path)
                    if not pix.isNull():
                        pix = pix.scaled(280, 220, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                        lbl.setPixmap(pix)
                        lbl.setAlignment(Qt.AlignCenter)
                        img_row.addWidget(lbl)
            layout.addLayout(img_row)
        layout.addStretch()
        version = QLabel("V8.4.6")
        version.setStyleSheet("font-size:10px; color:#888;")
        version.setAlignment(Qt.AlignCenter)
        layout.addWidget(version)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(dlg.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignCenter)
        self._suppress_autohide = True
        dlg.exec_()
        self._suppress_autohide = False

    # ============================================================
    # 设置
    # ============================================================

    def _show_settings_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("设置")
        dlg.setFixedSize(380, 520)
        dlg.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        dlg.setStyleSheet(themes.get_dialog_qss())
        layout = QVBoxLayout(dlg)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 16, 20, 16)

        # --- 关闭按钮行为 ---
        sec1 = QLabel("▎关闭按钮行为")
        sec1.setStyleSheet("font-size:12px;font-weight:bold;color:#e94560;")
        layout.addWidget(sec1)

        cb = models.get_setting("close_behavior", "quit", self._db_path)
        g1 = QButtonGroup(dlg)
        quit_rb = QRadioButton("关闭软件")
        tray_rb = QRadioButton("收起到系统托盘")
        quit_rb.setChecked(cb != "tray")
        tray_rb.setChecked(cb == "tray")
        g1.addButton(quit_rb); g1.addButton(tray_rb)
        layout.addWidget(quit_rb)
        layout.addWidget(tray_rb)

        # --- 分隔 ---
        sep = QLabel("")
        sep.setFixedHeight(1)
        sep.setStyleSheet("background-color:#2a2a4a;")
        layout.addWidget(sep)

        # --- 弹窗大小 ---
        sec2 = QLabel("▎快捷输入窗口适应")
        sec2.setStyleSheet("font-size:12px;font-weight:bold;color:#e94560;")
        layout.addWidget(sec2)

        ps = models.get_setting("popup_size", "fixed", self._db_path)
        g2 = QButtonGroup(dlg)
        fixed_rb = QRadioButton("固定大小")
        auto_rb = QRadioButton("自适应窗口")
        fixed_rb.setChecked(ps != "auto")
        auto_rb.setChecked(ps == "auto")
        g2.addButton(fixed_rb); g2.addButton(auto_rb)
        layout.addWidget(fixed_rb)
        layout.addWidget(auto_rb)

        # --- 分隔 ---
        sep2 = QLabel("")
        sep2.setFixedHeight(1)
        sep2.setStyleSheet("background-color:#2a2a4a;")
        layout.addWidget(sep2)

        # --- 语言 ---
        sec3 = QLabel("▎切换语言 / Language")
        sec3.setStyleSheet("font-size:12px;font-weight:bold;color:#e94560;")
        layout.addWidget(sec3)

        from src.locale import get_lang_mode, set_lang_mode
        g3 = QButtonGroup(dlg)
        follow_rb = QRadioButton("跟随系统")
        zh_rb = QRadioButton("中文")
        en_rb = QRadioButton("English")
        jp_rb = QRadioButton("日本語")
        cur = get_lang_mode()
        follow_rb.setChecked(cur == "follow")
        zh_rb.setChecked(cur == "zh")
        en_rb.setChecked(cur == "en")
        jp_rb.setChecked(cur == "jp")
        g3.addButton(follow_rb); g3.addButton(zh_rb); g3.addButton(en_rb); g3.addButton(jp_rb)
        layout.addWidget(follow_rb)
        layout.addWidget(zh_rb)
        layout.addWidget(en_rb)
        layout.addWidget(jp_rb)

        layout.addStretch()
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel_btn = QPushButton(t("btn_cancel"))
        cancel_btn.clicked.connect(dlg.reject)
        save_btn = QPushButton(t("btn_save"))
        save_btn.clicked.connect(dlg.accept)
        save_btn.setStyleSheet("QPushButton{background-color:#e94560;} QPushButton:hover{background-color:#ff6b81;}")
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

        self._suppress_autohide = True
        if dlg.exec_() == QDialog.Accepted:
            models.set_setting("close_behavior", "tray" if tray_rb.isChecked() else "quit", self._db_path)
            models.set_setting("popup_size", "auto" if auto_rb.isChecked() else "fixed", self._db_path)
            if follow_rb.isChecked(): set_lang_mode("follow")
            elif zh_rb.isChecked(): set_lang_mode("zh")
            elif en_rb.isChecked(): set_lang_mode("en")
            elif jp_rb.isChecked(): set_lang_mode("jp")
            models.set_setting("lang", get_lang_mode(), self._db_path)
        self._suppress_autohide = False

    def toggle_visible(self):
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.activateWindow()
            self.raise_()
            self._search_bar.setFocus()
            self._refresh_groups()
