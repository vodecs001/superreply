"""
主题系统 —— 日间 / 夜间 / 跟随系统（圆角跟随系统版本）
"""
import ctypes, json, os, sys
from datetime import datetime
from PyQt5.QtCore import QTimer
from src.db.models import get_setting, set_setting

# Windows 11 (build >= 22000) 用圆角，Windows 10 用直角
_win_build = sys.getwindowsversion().build
_R = "6" if _win_build >= 22000 else "0"

# ============================================================
# 夜间主题（全直角）
# ============================================================
DARK = """
QWidget { background-color: #1a1a2e; color: #eee; font-size: 13px; border-radius: {R}; }
QMainWindow { background-color: transparent; }

QLineEdit { background-color:#16213e; border:2px solid #2a2a4a; border-radius:%R%; padding:8px 12px; color:#eee; font-size:13px; }
QLineEdit:focus { border-color:#e94560; }

QPushButton { background-color:#0f3460; border:2px solid #2a2a4a; border-radius:%R%; padding:6px 16px; color:#eee; font-size:12px; }
QPushButton:hover { background-color:#e94560; border-color:#e94560; }

QTreeWidget { background-color:#1a1a2e; border:none; outline:none; padding:4px; }
QTreeWidget::item { padding:6px 8px; border-radius:%R%; color:#a0a0b0; }
QTreeWidget::item:hover { background-color:#e94560; color:#fff; }
QTreeWidget::item:selected { background-color:#0f3460; color:#eee; }
QTreeWidget::branch { background-color:transparent; }
QTreeWidget QHeaderView::section { background-color:#16213e; border:none; border-bottom:2px solid #2a2a4a; padding:6px; color:#a0a0b0; font-size:11px; font-weight:bold; }

QListWidget { background-color:#1a1a2e; border:none; outline:none; padding:4px; }
QListWidget::item { background-color:#1e1e3a; border:2px solid transparent; border-radius:%R%; margin:3px 6px; padding:10px 12px; color:#eee; }
QListWidget::item:hover { background-color:#252550; border-color:#2a2a4a; }
QListWidget::item:selected { background-color:#0f3460; border-color:#e94560; }

QScrollBar:vertical { background-color:#1a1a2e; width:8px; border-radius:%R%; }
QScrollBar::handle:vertical { background-color:#2a2a4a; border-radius:%R%; min-height:30px; }
QScrollBar::handle:vertical:hover { background-color:#e94560; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0 }
QScrollBar:horizontal { background-color:#1a1a2e; height:8px; border-radius:%R%; }
QScrollBar::handle:horizontal { background-color:#2a2a4a; border-radius:%R%; min-width:30px; }
QScrollBar::handle:horizontal:hover { background-color:#e94560; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0 }

QMenu { background-color:#16213e; border:2px solid #2a2a4a; border-radius:%R%; padding:4px; }
QMenu::item { padding:8px 24px; border-radius:%R%; color:#eee; }
QMenu::item:selected { background-color:#e94560; }

QStatusBar { background-color:#16213e; border-top:2px solid #2a2a4a; color:#a0a0b0; font-size:11px; padding:2px 8px; }
QSplitter::handle { background-color:#2a2a4a; width:2px; }
QSplitter::handle:hover { background-color:#e94560; }
QToolTip { background-color:#16213e; border:2px solid #2a2a4a; border-radius:%R%; padding:4px 8px; color:#eee; }
QTextEdit { background-color:#16213e; border:2px solid #2a2a4a; border-radius:%R%; padding:6px; color:#eee; }
QSpinBox { background-color:#16213e; border:2px solid #2a2a4a; border-radius:%R%; padding:5px 8px; color:#eee; }
QDialog { background-color:#1a1a2e; }
"""

# ============================================================
# 日间主题（纯白底 + 灰边框 + 红色强调 + 全直角）
# ============================================================
LIGHT = """
QWidget { background-color: #ffffff; color: #333; font-size: 13px; border-radius: {R}; }
QMainWindow { background-color: transparent; }

QLineEdit { background-color:#f8f9fa; border:2px solid #b0b5bd; border-radius:%R%; padding:8px 12px; color:#333; font-size:13px; }
QLineEdit:focus { border-color:#e94560; }

QPushButton { background-color:#f0f0f0; border:2px solid #b0b5bd; border-radius:%R%; padding:6px 16px; color:#333; font-size:12px; }
QPushButton:hover { background-color:#e94560; border-color:#e94560; color:#fff; }

QTreeWidget { background-color:#ffffff; border:none; outline:none; padding:4px; }
QTreeWidget::item { padding:6px 8px; border-radius:%R%; color:#555; }
QTreeWidget::item:hover { background-color:#e94560; color:#fff; }
QTreeWidget::item:selected { background-color:#fce4e8; color:#333; }
QTreeWidget::branch { background-color:transparent; }
QTreeWidget QHeaderView::section { background-color:#f0f0f0; border:none; border-bottom:2px solid #b0b5bd; padding:6px; color:#666; font-size:11px; font-weight:bold; }

QListWidget { background-color:#ffffff; border:none; outline:none; padding:4px; }
QListWidget::item { background-color:#f8f9fa; border:2px solid #d8dce3; border-radius:%R%; margin:3px 6px; padding:10px 12px; color:#333; }
QListWidget::item:hover { background-color:#fce4e8; border-color:#e94560; }
QListWidget::item:selected { background-color:#fce4e8; border-color:#e94560; }

QScrollBar:vertical { background-color:#ffffff; width:8px; border-radius:%R%; }
QScrollBar::handle:vertical { background-color:#c0c4cc; border-radius:%R%; min-height:30px; }
QScrollBar::handle:vertical:hover { background-color:#e94560; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0 }
QScrollBar:horizontal { background-color:#ffffff; height:8px; border-radius:%R%; }
QScrollBar::handle:horizontal { background-color:#c0c4cc; border-radius:%R%; min-width:30px; }
QScrollBar::handle:horizontal:hover { background-color:#e94560; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0 }

QMenu { background-color:#ffffff; border:2px solid #b0b5bd; border-radius:%R%; padding:4px; }
QMenu::item { padding:8px 24px; border-radius:%R%; color:#333; }
QMenu::item:selected { background-color:#e94560; color:#fff; }

QStatusBar { background-color:#f0f0f0; border-top:2px solid #b0b5bd; color:#666; font-size:11px; padding:2px 8px; }
QSplitter::handle { background-color:#b0b5bd; width:2px; }
QSplitter::handle:hover { background-color:#e94560; }
QToolTip { background-color:#ffffff; border:2px solid #b0b5bd; border-radius:%R%; padding:4px 8px; color:#333; }
QTextEdit { background-color:#f8f9fa; border:2px solid #b0b5bd; border-radius:%R%; padding:6px; color:#333; }
QSpinBox { background-color:#f8f9fa; border:2px solid #b0b5bd; border-radius:%R%; padding:5px 8px; color:#333; }
QDialog { background-color:#ffffff; }
"""

# 弹窗 - 夜间
POPUP_DARK = """
QWidget { background-color: #1a1a2e; }
QTreeWidget { background-color: #16213e; border: none; outline: none; color: #ccc; font-size: 12px; }
QTreeWidget::item { padding: 4px 6px; border-radius: {R}; }
QTreeWidget::item:hover { background-color: #e94560; color: #fff; }
QTreeWidget::item:selected { background-color: transparent; color: #ccc; }
QTreeWidget::branch { image: none; }
QListWidget { background-color: #1a1a2e; border: none; outline: none; color: #eee; font-size: 12px; }
QListWidget::item { background-color: #1e1e3a; border-radius: {R}; margin: 2px 4px; padding: 6px 8px; }
QListWidget::item:hover { background-color: #252550; }
QListWidget::item:selected { background-color: #0f3460; border: 1px solid #e94560; }
QSplitter::handle { background-color: #2a2a4a; width: 2px; }
QLabel { color: #888; font-size: 10px; background: transparent; padding: 4px; }
"""

# 弹窗 - 日间
POPUP_LIGHT = """
QWidget { background-color: #ffffff; }
QTreeWidget { background-color: #f5f6f8; border: none; outline: none; color: #333; font-size: 12px; }
QTreeWidget::item { padding: 4px 6px; border-radius: {R}; }
QTreeWidget::item:hover { background-color: #e94560; color: #fff; }
QTreeWidget::item:selected { background-color: transparent; color: #333; }
QTreeWidget::branch { image: none; }
QListWidget { background-color: #ffffff; border: none; outline: none; color: #333; font-size: 12px; }
QListWidget::item { background-color: #f8f9fa; border-radius: {R}; margin: 2px 4px; padding: 6px 8px; border: 1px solid #d8dce3; }
QListWidget::item:hover { background-color: #fce4e8; }
QListWidget::item:selected { background-color: #fce4e8; border: 1px solid #e94560; }
QSplitter::handle { background-color: #b0b5bd; width: 2px; }
QLabel { color: #666; font-size: 10px; background: transparent; padding: 4px; }
"""

def get_popup_qss() -> str:
    qss = POPUP_LIGHT if (_follow_system and _is_system_light()) or (_current_theme == "light" and not _follow_system) else POPUP_DARK
    return qss.replace("%R%", _R)


def _dialog_dark() -> str:
    return """QDialog,QWidget{background-color:#1a1a2e;color:#eee;font-size:13px;}
QLabel{color:#eee;font-size:12px;background:transparent;}
QLineEdit{background-color:#16213e;border:2px solid #2a2a4a;border-radius:%R%;padding:6px;color:#eee;}
QPushButton{background-color:#0f3460;border:2px solid #2a2a4a;border-radius:%R%;padding:6px 20px;color:#eee;}
QPushButton:hover{background-color:#e94560;}
QTextEdit{background-color:#16213e;border:2px solid #2a2a4a;border-radius:%R%;padding:6px;color:#eee;}
QSpinBox{background-color:#16213e;border:2px solid #2a2a4a;border-radius:%R%;padding:5px 8px;color:#eee;}"""

def _dialog_light() -> str:
    return """QDialog,QWidget{background-color:#fff;color:#333;font-size:13px;}
QLabel{color:#333;font-size:12px;background:transparent;}
QLineEdit{background-color:#f8f9fa;border:2px solid #b0b5bd;border-radius:%R%;padding:6px;color:#333;}
QPushButton{background-color:#f0f0f0;border:2px solid #b0b5bd;border-radius:%R%;padding:6px 20px;color:#333;}
QPushButton:hover{background-color:#e94560;color:#fff;}
QTextEdit{background-color:#f8f9fa;border:2px solid #b0b5bd;border-radius:%R%;padding:6px;color:#333;}
QSpinBox{background-color:#f8f9fa;border:2px solid #b0b5bd;border-radius:%R%;padding:5px 8px;color:#333;}"""

# ============================================================
# 导出 / 导入
# ============================================================
def export_phrases(filepath: str):
    """导出所有分组和短语到 JSON 文件"""
    from src.db.models import get_all_groups, build_group_tree, get_phrases
    flat = get_all_groups()
    tree = build_group_tree(flat)

    def _serialize(nodes):
        result = []
        for g in nodes:
            phrases = get_phrases(g["id"], limit=99999)
            result.append({
                "name": g["name"],
                "phrases": [{"title": p["title"], "content": p["content"]} for p in phrases],
                "children": _serialize(g.get("children", []))
            })
        return result

    data = {
        "version": 1,
        "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "groups": _serialize(tree)
    }
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def import_phrases(filepath: str) -> int:
    """从 JSON 导入分组和短语，返回导入的短语总数"""
    from src.db.models import create_group, add_phrase, get_all_groups, build_group_tree
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    total = 0
    def _import(nodes, parent_id=None):
        nonlocal total
        for g in nodes:
            gid = create_group(g["name"], parent_id)
            for p in g.get("phrases", []):
                add_phrase(gid, p.get("title", ""), p.get("content", ""))
                total += 1
            _import(g.get("children", []), gid)

    _import(data.get("groups", []))
    return total


# ============================================================
# 主题管理器
# ============================================================
_current_theme = "dark"
_follow_system = False
_callbacks = []

def get_current_qss() -> str:
    qss = LIGHT if (_follow_system and _is_system_light()) or (_current_theme == "light" and not _follow_system) else DARK
    return qss.replace("%R%", _R)

def get_dialog_qss() -> str:
    qss = _dialog_light() if (_follow_system and _is_system_light()) or (_current_theme == "light" and not _follow_system) else _dialog_dark()
    return qss.replace("%R%", _R)

def _is_system_light() -> bool:
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        val, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
        winreg.CloseKey(key)
        return val == 1
    except: return True

def set_theme(mode: str):
    global _current_theme, _follow_system
    if mode == "follow": _follow_system = True
    else: _follow_system = False; _current_theme = mode
    _notify()

def get_theme_mode() -> str:
    if _follow_system: return "follow"
    return _current_theme

def on_theme_change(cb): _callbacks.append(cb)

def _notify():
    qss = get_current_qss()
    for cb in _callbacks:
        try: cb(qss)
        except: pass

def load_theme():
    set_theme(get_setting("theme_mode", "dark"))

def save_theme(mode: str): set_setting("theme_mode", mode)

def start_follow_timer():
    last = _is_system_light()
    def check():
        nonlocal last
        cur = _is_system_light()
        if cur != last:
            last = cur
            _notify()
    timer = QTimer()
    timer.timeout.connect(check)
    timer.start(5000)
    return timer
