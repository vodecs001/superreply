"""
分组树组件 —— 无限层级、支持展开折叠、右键菜单
"""
from PyQt5.QtWidgets import (
    QTreeWidget, QTreeWidgetItem, QMenu, QAction, QInputDialog, QMessageBox,
    QHeaderView, QAbstractItemView,
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QFont

from src.locale import t


class GroupTree(QTreeWidget):
    """无限层级分组树"""

    group_selected = pyqtSignal(int, str)   # group_id, name
    clip_moved = pyqtSignal(int, int)       # clip_id, new_group_id

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()
        self._groups = []

    def _setup_ui(self):
        self.setHeaderLabels([t("group_header")])
        self.header().setStretchLastSection(True)
        self.header().setVisible(False)
        self.setIndentation(16)
        self.setAnimated(True)
        self.setExpandsOnDoubleClick(True)
        self.setDragEnabled(False)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.InternalMove)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_context_menu)
        self.itemClicked.connect(self._on_item_clicked)

    # ============================================================
    # 数据加载
    # ============================================================

    def load_groups(self, groups_tree: list[dict]):
        """从嵌套树加载到 QTreeWidget"""
        self._groups = groups_tree
        self.clear()
        for g in groups_tree:
            item = self._add_group_node(self, g, 0)
            item.setExpanded(True)

    def _add_group_node(self, parent, group: dict, depth: int = 0) -> QTreeWidgetItem:
        name = group.get("name", t("group_default_name"))
        gid = group.get("id", 0)
        # 附加短语数量
        from src.db.models import get_phrases
        phrases = get_phrases(gid, limit=99999)
        count_str = f" ({len(phrases)})" if len(phrases) > 0 else ""
        item = QTreeWidgetItem(parent)
        item.setText(0, name + count_str)
        item.setData(0, Qt.UserRole, gid)
        item.setFlags(item.flags())
        # 根分组：大字号加粗
        font = QFont()
        if depth == 0:
            font.setPointSize(11)
            font.setBold(True)
        else:
            font.setPointSize(10)
            font.setBold(False)
        item.setFont(0, font)
        for child in group.get("children", []):
            self._add_group_node(item, child, depth + 1)
        return item

    # ============================================================
    # 事件
    # ============================================================

    def _on_item_clicked(self, item: QTreeWidgetItem, col: int):
        gid = item.data(0, Qt.UserRole)
        name = item.text(0)
        self.group_selected.emit(gid, name)

    def _on_context_menu(self, pos):
        item = self.itemAt(pos)
        menu = QMenu(self)
        is_root = item and (item.parent() is None)  # 顶层 = 根分组

        add_root = None
        add_child = None
        rename_action = None
        delete_action = None

        if item is None:
            # 点击空白区域 → 创建根分组
            add_root = menu.addAction(f"➕ {t('group_new_root')}")
        elif is_root:
            add_phrase_action = menu.addAction(f"📝 {t('btn_add_phrase')}")
            add_child = menu.addAction(f"📁 {t('group_new_child')}")
            rename_action = menu.addAction(f"✏️ {t('group_rename')}")
            menu.addSeparator()
            delete_action = menu.addAction(f"🗑️ {t('group_delete')}")
        else:
            add_phrase_action = menu.addAction(f"📝 {t('btn_add_phrase')}")
            rename_action = menu.addAction(f"✏️ {t('group_rename')}")
            menu.addSeparator()
            delete_action = menu.addAction(f"🗑️ {t('group_delete')}")

        action = menu.exec_(self.viewport().mapToGlobal(pos))

        if action == add_root:
            self._add_group_flow(None)
        elif item and action == add_phrase_action:
            self.window()._phrase_list._on_add()
        elif item and action == add_child:
            gid = item.data(0, Qt.UserRole)
            self._add_group_flow(gid)
        elif item and action == rename_action:
            self._rename_group_flow(item)
        elif item and action == delete_action:
            self._delete_group(item)

    def _add_group_flow(self, parent_id: int | None):
        from src.db.models import create_group, get_all_groups, build_group_tree
        self.window()._suppress_autohide = True
        name, ok = QInputDialog.getText(self, t("group_new_dialog"), t("group_new_prompt"))
        self.window()._suppress_autohide = False
        if ok and name.strip():
            create_group(name.strip(), parent_id)
            self.load_groups(build_group_tree(get_all_groups()))

    def _delete_group(self, item: QTreeWidgetItem):
        from src.db.models import delete_group, get_all_groups, build_group_tree
        gid = item.data(0, Qt.UserRole)
        name = item.text(0)
        self.window()._suppress_autohide = True
        reply = QMessageBox.question(
            self, t("group_delete_title"),
            t("group_delete_confirm", name=name),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        self.window()._suppress_autohide = False
        if reply == QMessageBox.Yes:
            delete_group(gid)
            self.load_groups(build_group_tree(get_all_groups()))
            # 刷新短语列表
            if hasattr(self.window(), '_phrase_list'):
                self.window()._phrase_list.set_group(0)  # 0 = 清空显示
                self.window()._phrase_list.refresh()

    # ============================================================
    # 重命名（使用对话框，避免内联编辑的 QSS 文字截断问题）
    # ============================================================

    def _restore_selection(self, group_id: int):
        """恢复选中指定 ID 的分组"""
        def _find(item, gid):
            if item.data(0, Qt.UserRole) == gid:
                return item
            for i in range(item.childCount()):
                found = _find(item.child(i), gid)
                if found: return found
            return None
        for i in range(self.topLevelItemCount()):
            found = _find(self.topLevelItem(i), group_id)
            if found:
                self.setCurrentItem(found)
                return

    def _rename_group_flow(self, item: QTreeWidgetItem):
        from src.db.models import rename_group, get_all_groups, build_group_tree
        gid = item.data(0, Qt.UserRole)
        old_name = item.text(0)
        self.window()._suppress_autohide = True
        new_name, ok = QInputDialog.getText(
            self, t("group_rename"), t("group_new_prompt"), text=old_name
        )
        self.window()._suppress_autohide = False
        if ok and new_name.strip():
            rename_group(gid, new_name.strip())
            self.load_groups(build_group_tree(get_all_groups()))
