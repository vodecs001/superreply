"""国际化 / 多语言支持 — 跟随系统 / 中文 / English / 日本語"""
import ctypes
from enum import Enum

class Lang(Enum):
    EN = "en"
    ZH = "zh"
    JP = "jp"

_current_lang = Lang.ZH
_follow_system = False
_lang_callbacks = []

def detect_system_lang() -> Lang:
    """检测 Windows 系统语言"""
    try:
        lang_id = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        # 0x0804 = zh-CN, 0x0409 = en-US, 0x0411 = ja-JP
        if lang_id == 0x0411:
            return Lang.JP
        elif lang_id in (0x0804, 0x0409):
            return Lang.EN if lang_id == 0x0409 else Lang.ZH
    except:
        pass
    return Lang.ZH

def get_effective_lang() -> Lang:
    if _follow_system:
        return detect_system_lang()
    return _current_lang

def get_lang_mode() -> str:
    if _follow_system:
        return "follow"
    return _current_lang.value

def set_lang_mode(mode: str):
    global _current_lang, _follow_system
    if mode == "follow":
        _follow_system = True
    else:
        _follow_system = False
        for lang in Lang:
            if lang.value == mode:
                _current_lang = lang
                break
    _notify()

def set_lang(lang: Lang):
    global _current_lang, _follow_system
    _follow_system = False
    _current_lang = lang
    _notify()

def get_lang() -> Lang:
    return _current_lang

def on_lang_change(cb):
    _lang_callbacks.append(cb)

def _notify():
    for cb in _lang_callbacks:
        try: cb()
        except: pass

TR = {
    "app_title":    {"en": "Super Reply — Quick Phrase Manager", "zh": "超级回复 — 快捷短语管理器", "jp": "Super Reply — クイックフレーズ管理"},
    "app_short":    {"en": "Super Reply", "zh": "超级回复", "jp": "Super Reply"},
    "tray_tooltip": {"en": "Super Reply", "zh": "超级回复", "jp": "Super Reply"},
    "menu_show":    {"en": "Show/Hide", "zh": "显示/隐藏", "jp": "表示/非表示"},
    "menu_quit":    {"en": "Quit", "zh": "退出", "jp": "終了"},
    "btn_add_phrase": {"en": "Add Phrase", "zh": "添加短语", "jp": "フレーズ追加"},
    "btn_settings":   {"en": "Settings", "zh": "设置", "jp": "設定"},
    "btn_hotkey":     {"en": "Hotkey", "zh": "快捷键", "jp": "ホットキー"},
    "search_placeholder": {"en": "Search phrases...", "zh": "搜索短语...", "jp": "フレーズ検索..."},
    "status_ready":   {"en": "Ready", "zh": "就绪", "jp": "準備完了"},
    "status_count":   {"en": "{count} phrases", "zh": "{count} 条短语", "jp": "{count} 件"},
    "group_header":   {"en": "Groups", "zh": "分组", "jp": "グループ"},
    "group_new_root": {"en": "New Root Group", "zh": "新建根分组", "jp": "新規ルートグループ"},
    "group_new_child":{"en": "New Subgroup", "zh": "新建子分组", "jp": "新規サブグループ"},
    "group_rename":   {"en": "Rename", "zh": "重命名", "jp": "名前変更"},
    "group_delete":   {"en": "Delete", "zh": "删除", "jp": "削除"},
    "group_delete_title": {"en": "Delete Group", "zh": "删除分组", "jp": "グループ削除"},
    "group_delete_confirm": {"en": "Delete \"{name}\"?\nPhrases in it will also be deleted.", "zh": "确定删除 \"{name}\"？\n其中的短语也会被删除。", "jp": "\"{name}\" を削除しますか？\n中のフレーズも削除されます。"},
    "group_new_dialog":{"en": "New Group", "zh": "新建分组", "jp": "新規グループ"},
    "group_new_prompt":{"en": "Group name:", "zh": "分组名称:", "jp": "グループ名:"},
    "group_default_name":{"en": "Unnamed", "zh": "未命名", "jp": "無名"},
    "phrase_title_placeholder": {"en": "Phrase title (optional)", "zh": "短语标题（可选）", "jp": "タイトル(任意)"},
    "phrase_content_placeholder": {"en": "Phrase content...", "zh": "短语内容...", "jp": "内容..."},
    "phrase_paste":  {"en": "Paste", "zh": "粘贴", "jp": "貼り付け"},
    "phrase_edit":   {"en": "Edit", "zh": "编辑", "jp": "編集"},
    "phrase_delete": {"en": "Delete", "zh": "删除", "jp": "削除"},
    "phrase_pin":    {"en": "Pin", "zh": "置顶", "jp": "ピン留め"},
    "phrase_unpin":  {"en": "Unpin", "zh": "取消置顶", "jp": "ピン解除"},
    "phrase_empty":  {"en": "(no phrases)", "zh": "（暂无短语）", "jp": "（なし）"},
    "dlg_add_title": {"en": "Add Phrase", "zh": "添加短语", "jp": "フレーズ追加"},
    "dlg_edit_title":{"en": "Edit Phrase", "zh": "编辑短语", "jp": "フレーズ編集"},
    "dlg_title_label":{"en": "Title:", "zh": "标题:", "jp": "タイトル:"},
    "dlg_content_label":{"en": "Content:", "zh": "内容:", "jp": "内容:"},
    "btn_save":  {"en": "Save", "zh": "保存", "jp": "保存"},
    "btn_cancel":{"en": "Cancel", "zh": "取消", "jp": "キャンセル"},
    "settings_title": {"en": "Settings", "zh": "设置", "jp": "設定"},
    "settings_hotkey": {"en": "Global Hotkey:", "zh": "全局快捷键:", "jp": "ホットキー:"},
    "settings_hotkey_hint": {"en": "Press keys to capture", "zh": "输入或按键捕获", "jp": "キーを押して設定"},
    "settings_admin_hint": {"en": "(needs admin)", "zh": "（需管理员权限）", "jp": "（管理者権限必要）"},
    "hotkey_disabled": {"en": "[Hotkey] keyboard library not installed.", "zh": "[热键] keyboard 库未安装。", "jp": "[Hotkey] ライブラリ未導入。"},
    "hotkey_no_admin": {"en": "[Hotkey] Not running as admin.", "zh": "[热键] 未以管理员身份运行。", "jp": "[Hotkey] 管理者権限なし。"},
    "hotkey_admin_hint": {"en": "[Hotkey] Restart as Administrator.", "zh": "[热键] 请以管理员身份运行。", "jp": "[Hotkey] 管理者として再起動を。"},
    "popup_title": {"en": "Quick Paste", "zh": "快捷粘贴", "jp": "クイック貼付"},
    "theme_switch": {"en": "Theme", "zh": "主题切换", "jp": "テーマ切替"},
}

def t(key: str, **kwargs) -> str:
    lang = get_effective_lang()
    entry = TR.get(key, {})
    text = entry.get(lang.value, entry.get("en", key))
    return text.format(**kwargs) if kwargs else text
